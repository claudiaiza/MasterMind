function loadEvents ()
{
    document.getElementById("butreset").addEventListener ('click', reset)
    document.getElementById("butguess").addEventListener ('click', number1)
    document.getElementById("butguess").addEventListener ('click', number2)
    document.getElementById("butguess").addEventListener ('click', number3)
    document.getElementById("butguess").addEventListener ('click', number4)
    document.getElementById("butguess").addEventListener ('click', number5) 
    document.getElementById("butguess").addEventListener ('click', win) 
    n1 = Math.floor(Math.random()*10);
    n2 = Math.floor(Math.random()*10);
    n3 = Math.floor(Math.random()*10);
    n4 = Math.floor(Math.random()*10);
    n5 = Math.floor(Math.random()*10);
    console.log(n1, n2, n3, n4, n5)
    document.getElementById("span1").innerHTML = '*';
    document.getElementById("span2").innerHTML = '*';
    document.getElementById("span3").innerHTML = '*';
    document.getElementById("span4").innerHTML = '*';
    document.getElementById("span5").innerHTML = '*';
}

function number1 ()
{
    num1 = document.getElementById("number1").value;
    if (num1 != n1)
    {
        document.getElementById("error1").innerHTML = "numero 1 no acertado, intentalo de nuevo";
    }
    if (num1 <0 || num1 > 9)
    {
        document.getElementById("error1").innerHTML ="numero 1 fuera de la franja de 0-9, intentalo de nuevo"
    }
    if (num1 == '' || num1.length == 0)
    {
        document.getElementById("error1").innerHTML ="casilla 1 vacia, intentalo de nuevo"
    }
    else
    {
        if (num1 == n1)
        {
            document.getElementById("span1").innerHTML = n1;
            document.getElementById("number1").disabled = true
            document.getElementById("error1").innerHTML = '';
        }
    } 
}

function number2 ()
{
    num2 = document.getElementById("number2").value;
    if (num2 != n2)
    {
        document.getElementById("error2").innerHTML = "numero 2 no acertado, intentalo de nuevo";
    }
    if (num2 <0 || num2 > 9)
    {
        document.getElementById("error2").innerHTML ="numero 2 fuera de la franja de 0-9, intentalo de nuevo"
    }
    if (num2 == '' || num2.length == 0)
    {
        document.getElementById("error2").innerHTML ="casilla 2 vacia, intentalo de nuevo"
    }
    else
    {
        if (num2 == n2) 
        {
            document.getElementById("span2").innerHTML = n2;
            document.getElementById("number2").disabled = true
            document.getElementById("error2").innerHTML = '';
        }
    }
}

function number3 ()
{
    num3 = document.getElementById("number3").value;
    if (num3 != n3)
    {
        document.getElementById("error3").innerHTML = "numero 3 no acertado, intentalo de nuevo";
    }
    if (num3 <0 || num3 > 9)
    {
        document.getElementById("error3").innerHTML ="numero 3 fuera de la franja de 0-9, intentalo de nuevo"
    }
    if(num3 == '' || num3.length == 0)
    {
        document.getElementById("error3").innerHTML ="casilla 3 vacia, intentalo de nuevo"
    }
    else
    {
        if (num3 == n3)
        {
            document.getElementById("span3").innerHTML = n3;
            document.getElementById("number3").disabled = true
            document.getElementById("error3").innerHTML = '';
        }  
    }
}

function number4 ()
{
    num4 = document.getElementById("number4").value;
    if (num4 != n4)
    {
        document.getElementById("error4").innerHTML = "numero 4 no acertado, intentalo de nuevo";
    }
    if (num4 <0 || num4 > 9)
    {
        document.getElementById("error4").innerHTML ="numero 4 fuera de la franja de 0-9, intentalo de nuevo"
    }
    if(num4 == '' || num4.length == 0)
    {
        document.getElementById("error4").innerHTML ="casilla 4 vacia, intentalo de nuevo"
    }
    else
    {
        if (num4 == n4)
        {
            document.getElementById("span4").innerHTML = n4;
            document.getElementById("number4").disabled = true
            document.getElementById("error4").innerHTML = '';
        }     
    }
}

function number5 ()
{
    num5 = document.getElementById("number5").value;
    if (num5 != n5)
    {
        document.getElementById("error5").innerHTML = "numero 5 no acertado, intentalo de nuevo";
    }
    if (num5 <0 || num5 > 9)
    {
        document.getElementById("error5").innerHTML ="numero 5 fuera de la franja de 0-9, intentalo de nuevo"
    }
    if(num5 == '' || num5.length == 0)
    {
        document.getElementById("error5").innerHTML ="casilla 5 vacia, intentalo de nuevo"
    }
    else
    {
        if (num5 == n5)
        {
            document.getElementById("span5").innerHTML = n5;
            document.getElementById("number5").disabled = true
            document.getElementById("error5").innerHTML = '';
        }   
    }
}

function win ()
{

    if ((num1 == n1) && (num2 == n2) && (num3 == n3) && (num4 == n4) && (num5 == n5))
    {
        document.getElementById("congrats").innerHTML = "enhorabuena !!";
        document.getElementById("error1").innerHTML = '';
        document.getElementById("error2").innerHTML = '';
        document.getElementById("error3").innerHTML = '';
        document.getElementById("error4").innerHTML = '';
        document.getElementById("error5").innerHTML = '';
    }
}

function reset()
{
    n1 = Math.floor(Math.random()*10);
    n2 = Math.floor(Math.random()*10);
    n3 = Math.floor(Math.random()*10);
    n4 = Math.floor(Math.random()*10);
    n5 = Math.floor(Math.random()*10);
    console.log(n1, n2, n3, n4, n5)
    document.getElementById("span1").innerHTML = '*';
    document.getElementById("span2").innerHTML = '*';
    document.getElementById("span3").innerHTML = '*';
    document.getElementById("span4").innerHTML = '*';
    document.getElementById("span5").innerHTML = '*';
    document.getElementById("congrats").innerHTML = '';
    document.getElementById("number1").value = '';
    document.getElementById("number2").value = '';
    document.getElementById("number3").value = '';
    document.getElementById("number4").value = '';
    document.getElementById("number5").value = '';
    document.getElementById("error1").innerHTML = '';
    document.getElementById("error2").innerHTML = '';
    document.getElementById("error3").innerHTML = '';
    document.getElementById("error4").innerHTML = '';
    document.getElementById("error5").innerHTML = '';
    document.getElementById("number1").disabled = false
    document.getElementById("number2").disabled = false
    document.getElementById("number3").disabled = false
    document.getElementById("number4").disabled = false
    document.getElementById("number5").disabled = false
}
